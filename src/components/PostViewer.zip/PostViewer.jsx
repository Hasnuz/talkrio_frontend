import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Trash2, MoreVertical } from 'lucide-react';

// Fallback image in case of loading errors
const FALLBACK_IMAGE = '/placeholder.jpg';

export default function PostViewer() {
  const [posts, setPosts] = useState([
    {
      id: 1,
      // Use path to image in public folder
      image: '/images/p1.jpg', 
      likes: 120,
      comments: 30,
      username: "@traveler",
      caption: "Exploring beautiful landscapes 🏞️"
    },
    {
      id: 2,
      image: '/images/p2.jpg',
      likes: 98,
      comments: 12,
      username: "@adventurer",
      caption: "Sunset vibes 🌅"
    },
    {
      id: 3,
      image: '/images/post3.jpg',
      likes: 150,
      comments: 45,
      username: "@wanderer",
      caption: "Mountain peaks and fresh air 🏔️"
    }
  ]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [likes, setLikes] = useState(posts.map(p => ({
    count: p.likes,
    liked: false
  })));
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const containerRef = useRef(null);
  const scrollTimeoutRef = useRef(null);

  // Image error handling
  const handleImageError = (e) => {
    e.target.src = FALLBACK_IMAGE;
    console.warn(`Failed to load image for post ${posts[currentIndex].username}`);
  };

  const handleLike = () => {
    const newLikes = [...likes];
    const currentLike = newLikes[currentIndex];
    
    if (currentLike.liked) {
      // Unlike
      currentLike.count -= 1;
      currentLike.liked = false;
    } else {
      // Like
      currentLike.count += 1;
      currentLike.liked = true;
    }
    
    setLikes(newLikes);
  };

  const handleDelete = () => {
    const newPosts = posts.filter((_, index) => index !== currentIndex);
    setPosts(newPosts);
    
    // Adjust likes array
    const newLikes = likes.filter((_, index) => index !== currentIndex);
    setLikes(newLikes);

    // Reset index if needed
    setCurrentIndex(prevIndex => 
      prevIndex >= newPosts.length ? 0 : prevIndex
    );
    
    // Close menu
    setIsMenuOpen(false);
  };

  const smoothScroll = (direction) => {
    // Clear any existing timeout
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    // Smooth scroll logic
    scrollTimeoutRef.current = setTimeout(() => {
      setCurrentIndex(prevIndex => {
        if (direction === 'down') {
          return prevIndex + 1 >= posts.length ? 0 : prevIndex + 1;
        } else {
          return prevIndex - 1 < 0 ? posts.length - 1 : prevIndex - 1;
        }
      });
    }, 200); // Slight delay to prevent rapid scrolling
  };

  useEffect(() => {
    const handleWheel = (e) => {
      e.preventDefault(); // Prevent default scroll
      const { deltaY } = e;
      
      if (Math.abs(deltaY) > 30) { // Threshold to prevent tiny scrolls
        smoothScroll(deltaY > 0 ? 'down' : 'up');
      }
    };

    const container = containerRef.current;
    container?.addEventListener('wheel', handleWheel, { passive: false });

    return () => {
      container?.removeEventListener('wheel', handleWheel);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [posts.length]);

  if (posts.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-400 to-blue-500 flex justify-center items-center">
        <p className="text-white text-2xl">No more posts</p>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-sky-400 to-blue-500 flex justify-center items-center p-4 overflow-hidden"
    >
      <div className="relative w-96 h-[650px]">
        <AnimatePresence>
          <motion.div 
            key={posts[currentIndex].id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Image Container */}
            <div className="relative flex-grow">
              <img 
                src={posts[currentIndex].image} 
                onError={handleImageError}
                alt={`Post by ${posts[currentIndex].username}`}
                className="w-full h-full object-cover"
              />
              
              {/* More Options */}
              <div className="absolute top-4 right-4">
                <div className="relative">
                  <button 
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className="bg-white/50 rounded-full p-2 hover:bg-white/70 transition-all"
                  >
                    <MoreVertical className="w-5 h-5 text-gray-800" />
                  </button>
                  
                  {isMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute top-full right-0 mt-2 w-40 bg-white shadow-lg rounded-md overflow-hidden"
                    >
                      <button 
                        onClick={handleDelete}
                        className="w-full text-left px-4 py-2 hover:bg-red-50 flex items-center text-red-500"
                      >
                        <Trash2 className="mr-2 w-4 h-4" /> Delete Post
                      </button>
                    </motion.div>
                  )}
                </div>
              </div>
            </div>

            {/* Post Details */}
            <div className="p-4 bg-white border-t">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center space-x-2">
                  <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold">
                      {posts[currentIndex].username.charAt(1)}
                    </span>
                  </div>
                  <span className="font-semibold text-gray-800">
                    {posts[currentIndex].username}
                  </span>
                </div>

                <div className="flex space-x-3">
                  <button 
                    onClick={handleLike}
                    className="flex items-center text-gray-600 hover:text-red-500 transition-colors"
                  >
                    <Heart 
                      className={`w-5 h-5 ${likes[currentIndex].liked ? 'text-red-500 fill-current' : 'text-gray-400'}`} 
                    />
                    <span className="ml-1 text-sm">{likes[currentIndex].count}</span>
                  </button>
                  <button className="flex items-center text-gray-600 hover:text-blue-500 transition-colors">
                    <MessageCircle className="w-5 h-5 text-gray-400" />
                    <span className="ml-1 text-sm">{posts[currentIndex].comments}</span>
                  </button>
                </div>
              </div>
              <p className="text-gray-600 text-sm">
                {posts[currentIndex].caption}
              </p>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Post Count */}
        <div className="absolute bottom-[-30px] left-1/2 transform -translate-x-1/2 text-white">
          {currentIndex + 1} / {posts.length}
        </div>
      </div>
    </div>
  );
}